﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using TicketPortalMVC.Application.Services.Interface;
using TicketPortalMVC.Application.ViewModels;
using TicketPortalMVC.Domain.Entities;

namespace TicketPortalMVC.Web.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class OrderController : Controller
    {


        private readonly IOrderService _orderService;
        private readonly IAccountService _accountService;
        
        public OrderController(IOrderService orderService, IAccountService accountService)
        {
            _orderService = orderService;
            _accountService = accountService;
        }

        public IActionResult Index()
        {
            return View();
        }

        public async Task<IActionResult> OrderList()
        {
            var orders = await _orderService.GetOrdersAsync();
            return View(orders);
        }
        
        public async Task<IActionResult> OrderCreate()
        {
            var users = await _accountService.GetUsersAsync();

            var model = new OrderViewModel
            {
                Users = users
            };

            return View(model);
        }




    }
}
